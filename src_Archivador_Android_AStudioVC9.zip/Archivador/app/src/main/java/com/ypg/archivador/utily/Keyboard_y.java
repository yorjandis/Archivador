package com.ypg.archivador.utily;

import android.app.AlertDialog;
import android.content.Context;
import android.text.Editable;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.ypg.archivador.R;

public class Keyboard_y {

    private boolean isMayus = false;
    private boolean isSimb = false;

 private   Button btn_1,btn_2,btn_3,btn_4,btn_5,btn_6,btn_7,btn_8,btn_9,btn_10,
            btn_11,btn_12,btn_13,btn_14,btn_15,btn_16,btn_17,btn_18,btn_19,btn_20,
            btn_21,btn_22,btn_23,btn_24,btn_25,btn_26,btn_27;

    private Context G_Context;
    
    int index; //Almacena la posicon actual del cursor eb el edit
    
    public Keyboard_y(Context g_Context) {
        G_Context = g_Context;
    }






    //Muestra  el teclado virtual.
    // adicionalmente se puede pasar como parámetro un editText que tomará el valor puesto en el teclado al darle al boton copiar
    public void ShowKeyboard(EditText editText_P){
        AlertDialog.Builder builder = new AlertDialog.Builder(G_Context);
        builder.setTitle("Archivador - Teclado virtual");
        builder.setCancelable(false);

        EditText edit;


        Button btn_Mayus, btn_simb, btn_copy, btn_QR, btn_espacio;
        ImageButton btn_back, btn_home;

        View view = LayoutInflater.from(G_Context).inflate(R.layout.keyboard_y, null, false);

        edit        =      view.findViewById(R.id.modal_keyboard_edit);
        btn_Mayus   =      view.findViewById(R.id.modal_keyboard_btn_mayus);
        btn_simb    =      view.findViewById(R.id.modal_keyboard_btn_simb);
        btn_copy    =      view.findViewById(R.id.modal_keyboard_btn_copy);
        btn_QR      =      view.findViewById(R.id.modal_keyboard_btn_qr);
        btn_back    =      view.findViewById(R.id.modal_keyboard_back);
        btn_espacio =      view.findViewById(R.id.modal_keyboard_btn_espacio);
        btn_home    =      view.findViewById(R.id.modal_keyboard_btn_home);

        // losInstanciando botones
        btn_1 =   view.findViewById(R.id.modal_1);
        btn_2 =   view.findViewById(R.id.modal_2);
        btn_3 =   view.findViewById(R.id.modal_3);
        btn_4 =   view.findViewById(R.id.modal_4);
        btn_5 =   view.findViewById(R.id.modal_5);
        btn_6 =   view.findViewById(R.id.modal_6);
        btn_7 =   view.findViewById(R.id.modal_7);
        btn_8 =   view.findViewById(R.id.modal_8);
        btn_9 =   view.findViewById(R.id.modal_9);
        btn_10 =  view.findViewById(R.id.modal_10);
        btn_11 =  view.findViewById(R.id.modal_11);
        btn_12 =  view.findViewById(R.id.modal_12);
        btn_13 =  view.findViewById(R.id.modal_13);
        btn_14 =  view.findViewById(R.id.modal_14);
        btn_15 =  view.findViewById(R.id.modal_15);
        btn_16 =  view.findViewById(R.id.modal_16);
        btn_17 =  view.findViewById(R.id.modal_17);
        btn_18 =  view.findViewById(R.id.modal_18);
        btn_19 =  view.findViewById(R.id.modal_19);
        btn_20 =  view.findViewById(R.id.modal_20);
        btn_21 =  view.findViewById(R.id.modal_21);
        btn_22 =  view.findViewById(R.id.modal_22);
        btn_23 =  view.findViewById(R.id.modal_23);
        btn_24 =  view.findViewById(R.id.modal_24);
        btn_25 =  view.findViewById(R.id.modal_25);
        btn_26 =  view.findViewById(R.id.modal_26);
        btn_27 =  view.findViewById(R.id.modal_27);

        AsigngLetter(false); //Asignamiento inicial del texto en cada boton

        builder.setView(view);
        AlertDialog alertDialog = builder.create();


        btn_Mayus.setOnClickListener(v -> {
            if(isMayus){
                AsigngLetter(false);
                btn_Mayus.setText(btn_Mayus.getText().toString().toUpperCase());
                isMayus = false;
            }else{
                AsigngLetter(true);
                btn_Mayus.setText(btn_Mayus.getText().toString().toLowerCase());
                isMayus = true;
            }
        });

        btn_simb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isSimb){
                    if(isMayus){
                        AsigngLetter(true);
                        btn_Mayus.setText(btn_Mayus.getText().toString().toLowerCase());
                        isMayus = true;
                    }else{
                        AsigngLetter(false);
                        btn_Mayus.setText(btn_Mayus.getText().toString().toUpperCase());
                        isMayus = false;
                    }
                    isSimb = false;
                }else{
                    AsingSimbAndNumber();
                    isSimb = true;
                }

            }
        });

        btn_copy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //copiando el valor al control edit pasado como parámetro
                if (editText_P != null){
                    editText_P.setText(edit.getText().toString());

                }else{//si no se ha pasado un edit text copia el valor al portapales interno
                    UtilsY.valueCopy = edit.getText().toString();
                    Toast.makeText(G_Context, "Copiado al portapapeles interno", Toast.LENGTH_LONG).show();
                }
                alertDialog.dismiss();
            }
        });
        btn_QR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                modalGenerateQR modalGenerateQR = new modalGenerateQR(G_Context);
                modalGenerateQR.DialogGenerateQR(edit.getText().toString());
            }
        });

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index = edit.getSelectionStart();
                Editable editable = edit.getText();
                editable.delete(index-1, index);
            }
        });

        btn_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });
        btn_espacio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index = edit.getSelectionStart();
                Editable editable = edit.getText();
                editable.insert(index, " ");
            }
        });

        //Asignamiento de Onclik en cada boton

        btn_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index = edit.getSelectionStart();
                Editable editable = edit.getText();
                editable.insert(index, btn_1.getText().toString());
            }
        });
        btn_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index = edit.getSelectionStart();
                Editable editable = edit.getText();
                editable.insert(index, btn_2.getText().toString());
            }
        });
        btn_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index = edit.getSelectionStart();
                Editable editable = edit.getText();
                editable.insert(index, btn_3.getText().toString());
            }
        });
        btn_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index = edit.getSelectionStart();
                Editable editable = edit.getText();
                editable.insert(index, btn_4.getText().toString());
            }
        });
        btn_5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index = edit.getSelectionStart();
                Editable editable = edit.getText();
                editable.insert(index, btn_5.getText().toString());
            }
        });
        btn_6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index = edit.getSelectionStart();
                Editable editable = edit.getText();
                editable.insert(index, btn_6.getText().toString());
            }
        });
        btn_7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index = edit.getSelectionStart();
                Editable editable = edit.getText();
                editable.insert(index, btn_7.getText().toString());
            }
        });
        btn_8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index = edit.getSelectionStart();
                Editable editable = edit.getText();
                editable.insert(index, btn_8.getText().toString());
            }
        });
        btn_9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index = edit.getSelectionStart();
                Editable editable = edit.getText();
                editable.insert(index, btn_9.getText().toString());
            }
        });
        btn_10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index = edit.getSelectionStart();
                Editable editable = edit.getText();
                editable.insert(index, btn_10.getText().toString());
            }
        });
        btn_11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index = edit.getSelectionStart();
                Editable editable = edit.getText();
                editable.insert(index, btn_11.getText().toString());
            }
        });
        btn_12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index = edit.getSelectionStart();
                Editable editable = edit.getText();
                editable.insert(index, btn_12.getText().toString());
            }
        });
        btn_13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index = edit.getSelectionStart();
                Editable editable = edit.getText();
                editable.insert(index, btn_13.getText().toString());
            }
        });
        btn_14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index = edit.getSelectionStart();
                Editable editable = edit.getText();
                editable.insert(index, btn_14.getText().toString());
            }
        });
        btn_15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index = edit.getSelectionStart();
                Editable editable = edit.getText();
                editable.insert(index, btn_15.getText().toString());
            }
        });
        btn_16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index = edit.getSelectionStart();
                Editable editable = edit.getText();
                editable.insert(index, btn_16.getText().toString());
            }
        });
        btn_17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index = edit.getSelectionStart();
                Editable editable = edit.getText();
                editable.insert(index, btn_17.getText().toString());
            }
        });
        btn_18.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index = edit.getSelectionStart();
                Editable editable = edit.getText();
                editable.insert(index, btn_18.getText().toString());
            }
        });
        btn_19.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index = edit.getSelectionStart();
                Editable editable = edit.getText();
                editable.insert(index, btn_19.getText().toString());
            }
        });
        btn_20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index = edit.getSelectionStart();
                Editable editable = edit.getText();
                editable.insert(index, btn_20.getText().toString());
            }
        });
        btn_21.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index = edit.getSelectionStart();
                Editable editable = edit.getText();
                editable.insert(index, btn_21.getText().toString());
            }
        });
        btn_22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index = edit.getSelectionStart();
                Editable editable = edit.getText();
                editable.insert(index, btn_22.getText().toString());
            }
        });
        btn_23.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index = edit.getSelectionStart();
                Editable editable = edit.getText();
                editable.insert(index, btn_23.getText().toString());
            }
        });
        btn_24.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index = edit.getSelectionStart();
                Editable editable = edit.getText();
                editable.insert(index, btn_24.getText().toString());
            }
        });
        btn_25.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index = edit.getSelectionStart();
                Editable editable = edit.getText();
                editable.insert(index, btn_25.getText().toString());
            }
        });
        btn_26.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index = edit.getSelectionStart();
                Editable editable = edit.getText();
                editable.insert(index, btn_26.getText().toString());
            }
        });
        btn_27.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                index = edit.getSelectionStart();
                Editable editable = edit.getText();
                editable.insert(index, btn_27.getText().toString());
            }
        });

        alertDialog.show();

    }//Dialog ShowKeyboard


    //Asigna el texto de cada boton
    private void AsigngLetter(boolean mayus_P){

        if(mayus_P == false){
            btn_1.setText("q");
            btn_2.setText("w");
            btn_3.setText("e");
            btn_4.setText("r");
            btn_5.setText("t");
            btn_6.setText("y");
            btn_7.setText("u");
            btn_8.setText("i");
            btn_9.setText("o");
            btn_10.setText("p");
            btn_11.setText("a");
            btn_12.setText("s");
            btn_13.setText("d");
            btn_14.setText("f");
            btn_15.setText("g");
            btn_16.setText("h");
            btn_17.setText("j");
            btn_18.setText("k");
            btn_19.setText("l");
            btn_20.setText("ñ");
            btn_21.setText("z");
            btn_22.setText("x");
            btn_23.setText("c");
            btn_24.setText("v");
            btn_25.setText("b");
            btn_26.setText("n");
            btn_27.setText("m");
        }else{
            btn_1.setText("Q");
            btn_2.setText("W");
            btn_3.setText("E");
            btn_4.setText("R");
            btn_5.setText("T");
            btn_6.setText("Y");
            btn_7.setText("U");
            btn_8.setText("I");
            btn_9.setText("O");
            btn_10.setText("P");
            btn_11.setText("A");
            btn_12.setText("S");
            btn_13.setText("D");
            btn_14.setText("F");
            btn_15.setText("G");
            btn_16.setText("H");
            btn_17.setText("J");
            btn_18.setText("K");
            btn_19.setText("L");
            btn_20.setText("Ñ");
            btn_21.setText("Z");
            btn_22.setText("X");
            btn_23.setText("C");
            btn_24.setText("V");
            btn_25.setText("B");
            btn_26.setText("N");
            btn_27.setText("M");
        }



    }

    //Asigna caracteres y numeros
    private void AsingSimbAndNumber(){

        btn_1.setText("1");
        btn_2.setText("2");
        btn_3.setText("3");
        btn_4.setText("4");
        btn_5.setText("5");
        btn_6.setText("6");
        btn_7.setText("7");
        btn_8.setText("#");
        btn_9.setText("@");
        btn_10.setText("8");
        btn_11.setText("9");
        btn_12.setText("0");
        btn_13.setText("Є");
        btn_14.setText("_");
        btn_15.setText("&");
        btn_16.setText("-");
        btn_17.setText("+");
        btn_18.setText("(");
        btn_19.setText(")");
        btn_20.setText("*");
        btn_21.setText(":");
        btn_22.setText(",");
        btn_23.setText(";");
        btn_24.setText("?");
        btn_25.setText("¿");
        btn_26.setText("$");
        btn_27.setText(".");

    }


}
