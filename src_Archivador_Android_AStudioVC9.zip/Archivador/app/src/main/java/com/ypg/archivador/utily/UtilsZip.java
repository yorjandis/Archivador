package com.ypg.archivador.utily;


import android.content.Context;

import net.lingala.zip4j.ZipFile;

import java.io.File;

//ayuda con las operaciones de contenedor de archivos
public class UtilsZip {

    private String G_pathFilezip;

    //construcción
    public UtilsZip(Context context, String pathFileName) {
        G_pathFilezip = pathFileName;
    }

    //crear un vault
    private void createzip(){
        ZipFile zipFile = new ZipFile(G_pathFilezip);
    }


    

}
