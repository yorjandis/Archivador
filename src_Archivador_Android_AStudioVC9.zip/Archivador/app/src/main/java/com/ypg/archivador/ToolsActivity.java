package com.ypg.archivador;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.google.android.material.snackbar.Snackbar;
import com.ypg.archivador.utily.GetFilePath;
import com.ypg.archivador.utily.UisY;
import com.ypg.archivador.utily.UtilsY;
import com.ypg.archivador.utily.modalGenerateQR;

import java.io.File;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;

public class ToolsActivity extends AppCompatActivity implements View.OnClickListener {

    private static final int RESULTCODE = 1;
    Button btn_path, btn_encpFile, btn_decFile, btn_hashFile, btn_hashText, btn_checkHashFile, btn_checkHashText, btn_close;
    Button btn_enctext, btn_dectext, btn_keygenerator, btn_QRGenerator
            ;
    EditText edit_path, edit_pass, edit_text;
    Spinner spin_alg;

    private static final String[] alg = new String[]{"SHA-512", "SHA-384", "SHA-256", "SHA-1", "SHA", "MD5"};

    ConstraintLayout layoutroot;


    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tools);

        layoutroot = (ConstraintLayout) findViewById(R.id.activity_tools_root_layout);



        UtilsY.fragmentActualName = ""; //poniendo valor nulo porque no estoy dentro de un fragmento

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LOCKED);//bloquear rotacion de pantalla


        btn_path                = (Button) findViewById(R.id.tools_btn_papth);
        btn_encpFile            = (Button) findViewById(R.id.tools_btn_enc_fichero);
        btn_decFile             = (Button) findViewById(R.id.tools_btn_deenc_fichero);
        btn_enctext             = (Button) findViewById(R.id.tools_btn_enc_texto);
        btn_dectext             = (Button) findViewById(R.id.tools_btn_deenc_texto);
        btn_hashFile            = (Button) findViewById(R.id.tools_btn_hash_fichero);
        btn_hashText            = (Button) findViewById(R.id.tools_btn_hash_text);
        btn_checkHashFile       = (Button) findViewById(R.id.tools_btn_checkhash_fichero);
        btn_checkHashText       = (Button) findViewById(R.id.tools_btn_checkhash_text);
        btn_keygenerator        = (Button) findViewById(R.id.tools_btn_keygenerator);
        btn_QRGenerator         = (Button) findViewById(R.id.tools_btn_qrgenerator);
        btn_close               = (Button) findViewById(R.id.tools_btn_close);

        edit_path = (EditText) findViewById(R.id.tools_edit_papth);
        edit_pass = (EditText) findViewById(R.id.tools_edit_pass);
        edit_text = (EditText) findViewById(R.id.tools_edit_text);

        spin_alg = (Spinner) findViewById(R.id.tools_spin_algorit);
            spin_alg.setAdapter(new ArrayAdapter<String>(getBaseContext(), R.layout.support_simple_spinner_dropdown_item,alg));


        btn_close.setOnClickListener(this::onClick);
        btn_path.setOnClickListener(this::onClick);
        btn_encpFile.setOnClickListener(this::onClick);
        btn_decFile.setOnClickListener(this::onClick);
        btn_enctext.setOnClickListener(this::onClick);
        btn_dectext.setOnClickListener(this::onClick);
        btn_hashFile.setOnClickListener(this::onClick);
        btn_hashText.setOnClickListener(this::onClick);
        btn_checkHashFile.setOnClickListener(this::onClick);
        btn_checkHashText.setOnClickListener(this::onClick);
        btn_keygenerator.setOnClickListener(this::onClick);
        btn_QRGenerator.setOnClickListener(this::onClick);



    }




    @Override
    public void onClick(View v) {

       if(v == btn_close){
           super.onBackPressed();

       }
       else if(v == btn_path){
           edit_path.setEnabled(false);
           //Abriendo un cuadro de dialogo para seleccionar el fichero
           Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
           intent.setType("*/*");
           intent.addCategory(Intent.CATEGORY_OPENABLE);
           startActivityForResult(intent, ToolsActivity.RESULTCODE);
       }
       else if(v == btn_encpFile){ //encripta el fichero (le adiciona el prefijo:"_enc"
           edit_text.setText("");
                File file, file_enc;
           //Comprobación de campos:
           if(!edit_path.getText().toString().isEmpty() && !edit_pass.getText().toString().isEmpty()){
                    //encriptando...
               if (UtilsY.encryptFile(edit_pass.getText().toString(), edit_path.getText().toString(), edit_path.getText().toString() + "_enc")){

                   file = new File(edit_path.getText().toString());
                   file_enc = new File(edit_path.getText().toString() + "_enc");

                        if (file_enc.exists()){
                            edit_text.setText(">>"+ R.string.datos_del_fichero_original + "\n");
                            edit_text.append("Name: "+ file.getName() + "\n");
                            try {
                                edit_text.append("Hash ("+ spin_alg.getSelectedItem().toString()+ "): "+ UtilsY.hashFile(edit_path.getText().toString(), spin_alg.getSelectedItem().toString())+ "\n");
                            } catch (IOException e) {
                                UtilsY.msgY("Error: " + e);
                            } catch (NoSuchAlgorithmException e) {
                                UtilsY.msgY("Error: " + e);
                            }
                            edit_text.append(">>"+ R.string.tamano_bytes + file.length() + "\n");
                            edit_text.append(":::::::::::::::::::::::::::::::::::\n");


                            edit_text.append(">>"+getString(R.string.datos_del_fichero_encriptado)+ "\n");
                            edit_text.append(getString(R.string.nombre)+": \n");
                                try {
                                    //calculando el hash del fichero encriptado
                                    edit_text.append("Hash ("+ spin_alg.getSelectedItem().toString()+ "): "+ UtilsY.hashFile(edit_path.getText().toString() + "_enc", spin_alg.getSelectedItem().toString()) + "\n");
                                } catch (IOException e) {
                                    UtilsY.msgY("Error: " + e);
                                } catch (NoSuchAlgorithmException e) {
                                    UtilsY.msgY("Error: " + e);
                                }
                                //Calculando el tamaño del fichero encriptado
                            edit_text.append(getString(R.string.tamano_bytes) + file_enc.length());
                        }else{
                            UtilsY.msgY(getString(R.string.la_operación_ha_fallado));
                        }
               }else{
                   UtilsY.msgY(getString(R.string.la_operación_ha_fallado));
               }

           }else{
               UtilsY.msgY(getBaseContext().getString(R.string.debe_proveer_direccion_contraseña));
           }

       }
       else if(v == btn_decFile) { //Desencripta el fichero

           if(!edit_path.getText().toString().isEmpty() && !edit_pass.getText().toString().isEmpty()){
                File file_enc, file_dec;

               //desencriptando
              if (UtilsY.decryptFile(edit_pass.getText().toString(), edit_path.getText().toString(), edit_path.getText().toString()+ "_dec")) {
                  file_enc = new File(edit_path.getText().toString());
                  file_dec = new File(edit_path.getText().toString()+ "_dec");
                  //si se desencriptó realmente el fichero:
                  if (file_dec.exists()){
                      edit_text.setText(">>"+ getString(R.string.datos_del_fichero_encriptado) + "\n");
                      edit_text.append("Nombre: " + file_enc.getName() +"\n");
                      try {
                          edit_text.append("Hash ("+ spin_alg.getSelectedItem().toString()+ "): " + UtilsY.hashFile(edit_path.getText().toString(), spin_alg.getSelectedItem().toString()) + "\n");
                      } catch (IOException e) {
                          UtilsY.msgY("Error: " + e);
                      } catch (NoSuchAlgorithmException e) {
                          UtilsY.msgY("Error: " + e);
                      }
                      edit_text.append(getString(R.string.tamano_bytes) + file_enc.length() + "\n");
                      edit_text.append(":::::::::::::::::::::::::::::::::::\n");
                      edit_text.append(">>"+getString(R.string.datos_del_fichero_desencriptado));
                      edit_text.append("Name: " + file_dec.getName() +"\n");
                      try {
                          edit_text.append("Hash ("+ spin_alg.getSelectedItem().toString()+ "): " + UtilsY.hashFile(edit_path.getText().toString()+ "_dec", spin_alg.getSelectedItem().toString()) + "\n");
                      } catch (IOException e) {
                          UtilsY.msgY("Error: " + e);
                      } catch (NoSuchAlgorithmException e) {
                          UtilsY.msgY("Error: " + e);
                      }
                      edit_text.append(getString(R.string.tamano_bytes) + file_dec.length());
                  }else{
                      UtilsY.msgY(getString(R.string.la_operación_ha_fallado));
                  }

              }else{
                  UtilsY.msgY(getString(R.string.la_operación_ha_fallado));
              }
           }
       }
       else if(v == btn_enctext){ //Encriptando texto

           if (!edit_pass.getText().toString().isEmpty() && !edit_text.getText().toString().isEmpty() ) {
               try {
                   UisY uisY = new UisY(this, "",null);
                   uisY.DialogShowResultText(getResources().getString(R.string.encriptar_texto),getString(R.string.resultado),UtilsY.encriptarY(edit_text.getText().toString(),edit_pass.getText().toString()));

               } catch (Exception e) {
                   e.printStackTrace();
               }
           }else{
              showmsgY(getString(R.string.debe_colocar_un_texto_y_contraseña));
           }



       }
       else if(v == btn_dectext){//Desencriptando texto

           if (!edit_pass.getText().toString().isEmpty() && !edit_text.getText().toString().isEmpty() ) {

               UisY uisY = new UisY(this,"",null);
               try {
                   uisY.DialogShowResultText(getResources().getString(R.string.desencriptar_texto),getResources().getString(R.string.resultado),UtilsY.desencriptarY(edit_text.getText().toString(),edit_pass.getText().toString()));
               } catch (Exception e) {
                   e.printStackTrace();
               }
           }else{
               showmsgY(getResources().getString(R.string.debe_colocar_un_texto_y_contraseña));
           }



       }
       else if(v == btn_hashFile){

           if(!edit_path.getText().toString().isEmpty()){

               try {
                 String hash =   UtilsY.hashFile(edit_path.getText().toString(), spin_alg.getSelectedItem().toString());
                   if (!hash.isEmpty()){
                       edit_text.setText("The hash "+spin_alg.getSelectedItem().toString() +" of file is: "+ hash);
                   }else {
                       UtilsY.msgY(getString(R.string.la_operación_ha_fallado));
                   }


               } catch (IOException e) {
                   UtilsY.msgY("Error: " + e);
               } catch (NoSuchAlgorithmException e) {
                   UtilsY.msgY("Error: " + e);
               }

           }else{
               UtilsY.msgY(getString(R.string.debe_establecer_la_ruta_de_un_fichero));
           }

       }
       else if (v == btn_hashText){

           if(!edit_text.getText().toString().isEmpty()){
               String hash;

              hash =  UtilsY.hashText(edit_text.getText().toString(), spin_alg.getSelectedItem().toString());
                    edit_text.append("\n\n Hash: "+ hash);

           }else{
               UtilsY.msgY(getString(R.string.debe_establecer_un_texto_para_calcular_su_hash));
           }


       }
       else if(v ==  btn_checkHashFile){

           if(!edit_path.getText().toString().isEmpty() && !edit_text.getText().toString().isEmpty()){
                String hashfile;
               try {
                   hashfile =   UtilsY.hashFile(edit_path.getText().toString(), spin_alg.getSelectedItem().toString());
                   if (hashfile.equals(edit_text.getText().toString())){
                       edit_text.append("\n\n"+ getString(R.string.el_hash_coincide));
                   }else{
                       edit_text.append("\n\n"+ getString(R.string.los_hash_NO_son_iguales));
                   }
               } catch (IOException e) {
                   UtilsY.msgY("Error: " + e);
               } catch (NoSuchAlgorithmException e) {
                   UtilsY.msgY("Error: " + e);
               }


           }else{
               UtilsY.msgY(getString(R.string.debe_establecer_un_fichero_y_un_hash));
           }


       }
       else if(v == btn_checkHashText) {

           if (edit_path.isEnabled()){
             if(UtilsY.hashTextCheck(edit_text.getText().toString(), edit_path.getText().toString(), spin_alg.getSelectedItem().toString())){
                 UtilsY.msgY(getString(R.string.el_hash_coincide));
             } else{
                 UtilsY.msgY(getString(R.string.el_hash_NO_Coincide));
             }
                edit_path.setText("");
               edit_path.setEnabled(false);
           }else{ //Si el edit no esta habilitado: se informa y se habilita.
               UtilsY.msgY(getString(R.string.colocar_el_hash_en_a_comprobrar_en_el_cuadro));
               edit_path.setText("");
               edit_path.setEnabled(true);
           }
       }
       else if(v == btn_keygenerator) {
           UisY uisY = new UisY(this,"",null);
           uisY.DialogKeyGenerator();

       }else if(v == btn_QRGenerator){

           modalGenerateQR modalGenerator = new modalGenerateQR(this);

           modalGenerator.DialogGenerateQR("Pass");

       }


    }//onclick



    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RESULTCODE){
            if (resultCode == RESULT_OK){
                Uri uu = null;
                if (data != null){
                    uu = data.getData();
                    String s = GetFilePath.getPathFromUri(getApplicationContext(),uu);
                    edit_path.setText(s);
                }
            }
        }

    }






    public void showmsgY(String msg){
        Snackbar snackbar = Snackbar.make(edit_text, msg,Snackbar.LENGTH_SHORT);
        snackbar.setAnimationMode(Snackbar.ANIMATION_MODE_SLIDE);
        snackbar.show();
    }


}//class