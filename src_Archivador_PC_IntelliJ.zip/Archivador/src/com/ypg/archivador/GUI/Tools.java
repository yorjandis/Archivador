package com.ypg.archivador.GUI;

import com.ypg.archivador.Util.Utils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;

public class Tools extends JFrame{
    private JPanel rootPanel;
    private JTextField edit_fileBrowser;
    private JButton btn_fileBrowser;
    private JTextArea edit_text;
    private JButton btn_calcHash_file;
    private JButton btn_calcHash_text;
    private JButton btn_desencrypt_File;
    private JButton btn_chechHash_File;
    private JButton btn_ChechHash_text;
    private JButton btn_encrypt_File;
    private JComboBox combo_ALG;
    private JPasswordField edit_Pass;
    private JPanel panelParemetros;
    private JPanel panelOperaciones;
    private JPanel panelPass;
    private JPanel panelALG;
    private JScrollPane scrollpane;

    private static String  G_Filename; //almacena el nombre del fichero cargado

    public Tools() {
        setResizable(false); //no permite que la ventana se pueda ajustar en RT
        setContentPane(rootPanel);  // mismo efecto que // add(rootPanel);
        setSize(900,350);
        setTitle("Archivador - Panel de herramientas"); //titulo de la ventana
        setLocation( Toolkit.getDefaultToolkit().getScreenSize().width/4-20,Toolkit.getDefaultToolkit().getScreenSize().height/4+20); //centrando la ventana
        edit_text.setLineWrap(true); //cortar las lineas al final;
        edit_text.setWrapStyleWord(true);


        //Botón file browser: Carga el path de un fichero
        btn_fileBrowser.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                JFileChooser file = new JFileChooser();
                int returnVal = file.showOpenDialog(Tools.this);
                if(returnVal == JFileChooser.APPROVE_OPTION) {
                    String filename = file.getSelectedFile().toString();
                    edit_fileBrowser.setText(filename);
                    G_Filename = file.getSelectedFile().getName(); //se almacena el nombre del fichero
                }
            }
        });

        //Botónn Encriptar fichero:
        btn_encrypt_File.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                    //si se ha dado un fichero y un pass:

                if (!edit_fileBrowser.getText().equals("") &&  !String.valueOf(edit_Pass.getPassword()).equals("")){
                    File file = new File(edit_fileBrowser.getText());

                    if (file.exists()) { //Si existe el fichero a encriptar
                        String alg = combo_ALG.getSelectedItem().toString(); //tomando el algoritmo de hash selecionado
                        edit_text.setText(""); //reseteando el control
                        if (Utils.encryptFile(String.valueOf(edit_Pass.getPassword()), edit_fileBrowser.getText(), edit_fileBrowser.getText() + "_enc"));
                        edit_text.append("Se ha creado con éxito el fichero encriptado: "+G_Filename + "_enc\n");
                            try {
                                edit_text.append("Hash ("+ alg+") del fichero encriptado: " + Utils.hashFile(edit_fileBrowser.getText() + "_enc",alg)+"\n");
                            } catch (IOException ioException) {
                                ioException.printStackTrace();
                            } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
                                noSuchAlgorithmException.printStackTrace();
                            }

                            File file2 = new File(edit_fileBrowser.getText() + "_enc");
                        edit_text.append("Tamaño (en bytes): "+ file2.length());
                    }//if
                }else{
                    JOptionPane.showMessageDialog(Tools.this,"Error: Debe colocar un fichero y password válido");
                }//if

            }
        });

        //Botón Desencriptar fichero:
        btn_desencrypt_File.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (!edit_fileBrowser.getText().equals("") &&  !String.valueOf(edit_Pass.getPassword()).equals("")){

                  if ( Utils.decryptFile(String.valueOf(edit_Pass.getPassword()),edit_fileBrowser.getText(),edit_fileBrowser.getText()+"_dec")) {
                      File file = new File(edit_fileBrowser.getText()+"_dec");
                      edit_text.setText(("Fichero desencriptado correctamente: "+file.getName()));
                  }else{
                      JOptionPane.showMessageDialog(Tools.this, "Error: "+ e);
                  }

                }


            }
        });

        //Boton Calcular hash de fichero
        btn_calcHash_file.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (!edit_fileBrowser.getText().equals("")){
                    String alg = combo_ALG.getSelectedItem().toString();
                    edit_text.setText(""); //reseteando el control:
                    try {
                        edit_text.setText("El hash ("+ alg+") del fichero es: "+ Utils.hashFile(edit_fileBrowser.getText(),alg));
                    } catch (IOException ex) {
                        JOptionPane.showMessageDialog(Tools.this, "Error: "+ex);
                    } catch (NoSuchAlgorithmException ex) {
                        JOptionPane.showMessageDialog(Tools.this, "Error: "+ex);
                    }
                }else{
                    JOptionPane.showMessageDialog(Tools.this,"Debe seleccionar un fichero");
                }

            }
        });

        //Boton Check Hash de fichero
        btn_chechHash_File.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!edit_fileBrowser.getText().equals("")) {
                    edit_text.setText("");
                    String alg = combo_ALG.getSelectedItem().toString();
                    String temp = JOptionPane.showInputDialog("Pegue el Hash de comprobación ("+combo_ALG.getSelectedItem().toString()+")").trim();
                        if (!temp.equals("")){
                            if  (Utils.hashFileCheck(edit_fileBrowser.getText(),alg,temp)){
                                edit_text.setText("Comprobación exitosa, el fichero no se ha modificado");
                            }else{
                                edit_text.setText("La comprobación ha fallado. Puede que el fichero se haya modificado");
                            }
                        }
                }else{
                    JOptionPane.showMessageDialog(Tools.this,"Error: Debe seleccionar un fichero");
                }
            }
        });

        //Boton calcular hash de texto
        btn_calcHash_text.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!edit_text.getText().equals("")){
                    edit_fileBrowser.setText(Utils.hashText(edit_text.getText(), combo_ALG.getSelectedItem().toString()));
                }else {
                    JOptionPane.showMessageDialog(Tools.this, "Debe colocar un texto");
                }

            }
        });

        //Boton chequear hash de texto
        btn_ChechHash_text.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if (!edit_text.getText().equals("")){
                    String a = JOptionPane.showInputDialog("Coloque el hash de comprobación ("+combo_ALG.getSelectedItem().toString()+")").trim();
                    if (!a.equals("")){

                       if(Utils.hashTextCheck(edit_text.getText(),a,combo_ALG.getSelectedItem().toString())) {
                           JOptionPane.showMessageDialog(Tools.this,"Comprobación exitosa!");
                       }else{
                           JOptionPane.showMessageDialog(Tools.this,"Fallo en la comprobación!");
                       }
                    }
                }else{
                    JOptionPane.showMessageDialog(Tools.this, "Error: Debe poner el texto a comprobar");
                }

            }
        });

    }



}
