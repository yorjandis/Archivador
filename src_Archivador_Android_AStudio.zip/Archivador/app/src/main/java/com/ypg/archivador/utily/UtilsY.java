package com.ypg.archivador.utily;

//Clase de funciones utilitarias:

import android.annotation.SuppressLint;
import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.text.TextUtils;
import android.widget.Toast;

import com.ypg.archivador.MainActivity;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class UtilsY {

    public static  Context G_context;


    //Variables Globales


    private static final String ALG = "AES"; //Algoritmo utilizado

    public static String G_patBD = "";              //almacena la ruta del archivo actual de la BD (se modifica en f_AbrirBD.java)
    public  static  String pass = "";               //Almacena la clave actual de cifrado/descifrado dada por el usuario.
    public static String passEncripted = "";        //Almacena la clave de escriptación actual
    public  static int spinCatgItemposition = -1;   //Almacena el item actualmente seleccionado en la lista de Categorias
    public static boolean isEditModif = false;      //Para chequear si el edittext de los values ha cambiado su contenido
    public static boolean isBDOpenEnc = false;      //Almacena true, si la BD se desencriptó al abrir
    public static boolean isBDOpenEncMismaPass = false; //si al abrir la base de datos esta se descriptó con la misma clave de cifrado
    public  static boolean privacyisAcepted = false;  //especifica si se ha aceptado (true) los terminos y condidiones


//FUNCIONES GNERALES ::::::::::::::::::::::::::::::::::::::



//FUNCIONES fichero INI::::::::::::::::

    //función que crea la base de datos en la raíz de la memmoria. No la carga en la GUI
    public  static boolean crearBDY(String pathBDP, String passP) throws Exception {
        //Crear el fichero en la memoria

        //Lista de Categorias por defecto a adicionar (Ya encriptadas)
        List<String> CatgDefault = new ArrayList<>();
        CatgDefault.add("[" + encriptarY("NOTAS", passP)        + "]");
        CatgDefault.add("[" + encriptarY("IDENTIDAD", passP)    + "]");
        CatgDefault.add("[" + encriptarY("BANCOS", passP)       + "]");
        CatgDefault.add("[" + encriptarY("CONTRASEÑAS", passP)  + "]");
        CatgDefault.add("[" + encriptarY("FINANZAS", passP)     + "]");
        CatgDefault.add("[" + encriptarY("WEBS", passP)         + "]");

        //Creando y Chequeando que el nuevo fichero a crear
        try {
            File file = new File(pathBDP);

                try {
                    OutputStreamWriter write;
                    write = new OutputStreamWriter(new FileOutputStream(file));

                    for (int i = 0; i < CatgDefault.size(); i++){
                        write.write(CatgDefault.get(i) + "\n" );
                    }

                    write.close(); //escribe los valores y cierra el fichero
                       return true;
                }catch (Exception e){
                    return  false;
                }

        } catch (Exception e){
         return  false;
        }

    }


    //Devuelve la lista de categorias de la BD
    public  static List<String> loadCatg(){
        //File inifile = new File(Environment.getExternalStorageDirectory() + "/yorjj.txt");

        List<String> lista = new ArrayList<>();


        if (G_patBD.equals("") || !new File(G_patBD).exists()){ return lista;} //No carga la BD

        try {
            JIniFile ini = new JIniFile(UtilsY.G_patBD);
            ArrayList<String> sections =  ini.ReadSections(); //Obteniendo todas las secciones (Categorias)

            if (sections.size() > 0) { //si existen secciones que cargar
                //recorriendo las secciones para descifrarlas


                for (int i = 0; i < sections.size(); i++){

                    lista.add(desencriptarY(sections.get(i), pass));
                }
                
                return lista;

            }else{
                msgY("El fichero de BD esta vacio");
            }

        }catch (Exception e){

            msgY( "Error: "+ e);
        }


        msgY( "casi me voy");
        return  lista;
    }


    //Devuelve las entradas para una Categoria Dada
    public static List<String> loadEnt(String Catg){

        List<String>  lista = new ArrayList<>();

        try{
            JIniFile ini = new JIniFile(G_patBD);
            ArrayList<String> list = ini.ReadSection(encriptarY(Catg,pass)); //Obteniendo todas las keys de una sección

            if (list.size() > 0) { //si existen entradas que cargar
                //recorriendo las secciones para descifrarlas

                for (int i = 0; i < list.size(); i++){
                   lista.add(desencriptarY(list.get(i), pass));
                }

                return lista;
            }

        }catch (Exception e){
            msgY("Error: " + e);
        }

        return lista;
    }


    //Devuelve el contenido de una entrada OK
    public static String loadEntvalues(String Catg, String Ent, String ValueDefault){
        String resul = "";

        try{
            JIniFile ini = new JIniFile(G_patBD);
            resul = desencriptarY(ini.ReadString(encriptarY(Catg,pass), encriptarY(Ent,pass), ValueDefault),pass);
        }catch (Exception e){
            msgY("Error: " + e);
        }
        //Reemplazando los caracteres especiales de espacio por saltos de linea
        resul =  resul.replaceAll("%/", "\n");
        return resul;
    }

    //Adicionar nueva Categoria a la BD OK
    public static Boolean addNewCatg(String catg){

        boolean resul = false;
        try{
            JIniFile ini = new JIniFile(UtilsY.G_patBD);
            ini.WriteString(encriptarY(catg,pass),encriptarY("EntEjemplo",pass), encriptarY("ValorEjemplo",pass));
            ini.UpdateFile();
            resul = true;
        }catch(Exception e){
            msgY("Error: "+ e);
        }

        return  resul;
    } //AddNewCatg


    //Eliminar una Categoria de la BD OK
    public static Boolean delCateg(String Catg){
        boolean resul = false;
        if (G_patBD.equals("") || !new File(G_patBD).exists()){ return resul;} //No carga la BD
        try {
            JIniFile ini = new JIniFile(G_patBD);
            ini.EraseSection(encriptarY(Catg,pass));
            //error con ini.UpdateFile()
            resul = ini.UpdateFile();
        }catch (Exception e){
            msgY("Error: " + e);
        }
        return resul;
    }

    //Elimina una entrada (key) de una categoría dada
    public static Boolean delEnt(String Catg, String Ent){
        boolean resul = false;

        try{
            JIniFile ini = new JIniFile(G_patBD);
            ini.DeleteKey(encriptarY(Catg,pass),encriptarY(Ent,pass));
            resul = ini.UpdateFile();
        }catch (Exception e){
            msgY("Error: "+ e);
        }
        return resul;
    }

    //Adiciona una nueva entrada en una categoría dada OK
    public static Boolean addNewEnt(String Catg, String NewEnt, String NewValueDefault){
        boolean resul = false;
        try{

            JIniFile ini = new JIniFile(G_patBD);
            ini.WriteString(encriptarY(Catg,pass), encriptarY(NewEnt, pass),encriptarY(NewValueDefault,pass));
            resul = ini.UpdateFile();
        }catch (Exception e){
            msgY("Error: " + e);
        }

        return resul;
    }

    //Modifica el value de una entrada
    public static Boolean modEnt(String Catg, String Ent, String ValueDefault){
        boolean resul = false;
        try{
            JIniFile ini = new JIniFile(G_patBD);
            ini.WriteString(encriptarY(Catg,pass), encriptarY(Ent, pass),encriptarY(ValueDefault,pass));
            resul = ini.UpdateFile();
        }catch (Exception e){
            msgY("Error: " + e );
        }

        return resul;
    }

    //Función útil: determina si existe una categoria ya en el fichero INI
    public static boolean containCatginIni(String Catg){

        boolean resul = false;
        if (G_patBD.equals("") || !new File(G_patBD).exists()){ return resul;} //No carga la BD

        try {
            JIniFile ini = new JIniFile(G_patBD);
            ArrayList<String> sections = ini.ReadSections(); //Obteniendo todas las secciones

            for (int i= 0; i < sections.size(); i++){
                if (desencriptarY(sections.get(i), pass).equalsIgnoreCase(Catg)){
                    return  true;
                }
            }
        }catch (Exception e){
            msgY("YY"+e);
        }
        return resul;
    }


    // FUNCIONES DE CIFRADO Y DESCIFRADO :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

    //Cifrar un texto
    public static String encriptarY(String txtToEncode, String pass) throws Exception {

        SecretKeySpec secretKeySpec = generarkeyY(pass);
        Cipher cipher = Cipher.getInstance(ALG);
        cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec);
        byte[] datosencriptados = cipher.doFinal(txtToEncode.getBytes());
        String datos =  android.util.Base64.encodeToString(datosencriptados, android.util.Base64.NO_PADDING + android.util.Base64.URL_SAFE);
        //String datos = Base64.encodeToString(datosencriptados, Base64.URL_SAFE + Base64.NO_PADDING);
        datos = datos.replace("\n", ""); //quitando los saltos de linea
        return datos;
    }

    //Descifrar un texto
    public static String desencriptarY(String txtToDecode, String pass) throws Exception {
        SecretKeySpec secretKeySpec = generarkeyY(pass);
        Cipher cipher = Cipher.getInstance(ALG);
        cipher.init(Cipher.DECRYPT_MODE, secretKeySpec);
        byte[] datosdesencriptados = android.util.Base64.decode(txtToDecode, android.util.Base64.URL_SAFE);
        //byte[] datosdesencriptados = Base64.decode(txten,Base64.URL_SAFE + Base64.NO_PADDING);
        byte[] datos = cipher.doFinal(datosdesencriptados);
        String resul = new String(datos);
        resul = resul.replace("\n", "");//quitando los saltos de linea
        return resul;
    }

    //encriptar un fichero
    public static Boolean encryptFile(String key, String inputFilea, String outputFilea) {
        try {
            SecretKeySpec secretKeySpec = generarkeyY(key);
            File inputFile = new File(inputFilea); //fichero de entrada
            File outputFile = new File(outputFilea); //fichero de salida (encriptado)
            doCrypto(Cipher.ENCRYPT_MODE, secretKeySpec, inputFile, outputFile);
            return true;
        }catch (Exception e){
            return false;
        }
    }

    //desencriptar un fichero
    public static Boolean decryptFile(String key, String inputFilea, String outputFilea) {
        try{
            SecretKeySpec secretKeySpec = generarkeyY(key);
            File inputFile = new File(inputFilea); //fichero de entrada (encriptado)
            File outputFile = new File(outputFilea); //fichero de salida
            doCrypto(Cipher.DECRYPT_MODE, secretKeySpec, inputFile, outputFile);
            return true;
        }catch (Exception e){
            return false;
        }
    }

    //calcula y devuelbe  el hash de un fichero.
    public static String hashFile(String filepath, String alg) throws IOException, NoSuchAlgorithmException {
        // Set your algorithm
        // "MD2","MD5","SHA","SHA-1","SHA-256","SHA-384","SHA-512"

        File file = new File(filepath);

        if (file.exists()){
            MessageDigest md = MessageDigest.getInstance(alg); //el parametro alg contiene el algoritmo a utilizar
            FileInputStream fis = new FileInputStream(file);
            byte[] dataBytes = new byte[1024];

            int nread;
            while ((nread = fis.read(dataBytes)) != -1) {
                md.update(dataBytes, 0, nread);
            }

            byte[] mdbytes = md.digest();

            StringBuilder sb = new StringBuilder();
            for (byte mdbyte : mdbytes) {
                sb.append(Integer.toString((mdbyte & 0xff) + 0x100, 16).substring(1));
            }
            return sb.toString();
        }
        return "";

    }

    //Comprueba el hash de un fichero
    public static Boolean hashFileCheck(String filePath, String hashAlg, String hash) {

        try {
            String s =  hashFile(filePath,hashAlg);
            return s.contentEquals(hash); //el hash coincide
        } catch (Exception e) {
            System.out.print("Error: "+ e);
        }
        return false;
    }

    //Calcula el hash de un texto
    public static String hashText(String text, String alghash){
        byte[] hash = null;
        try {
            MessageDigest md = MessageDigest.getInstance(alghash);
            hash = md.digest(text.getBytes());

        } catch (NoSuchAlgorithmException e) { e.printStackTrace(); }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < hash.length; ++i) {
            String hex = Integer.toHexString(hash[i]);
            if (hex.length() == 1) {
                sb.append(0);
                sb.append(hex.charAt(hex.length() - 1));
            } else {
                sb.append(hex.substring(hex.length() - 2));
            }
        }
        return sb.toString();
    }

    //Comprueba el hash de un texto
    public static Boolean hashTextCheck(String text, String hash, String alg){
        String temp = hashText(text,alg);
        return temp.equals(hash);
    }

    //Genera una Secrekey A partir de una clave dada por el usuario
    private static SecretKeySpec generarkeyY(String pass) throws Exception {
        MessageDigest sha = MessageDigest.getInstance("SHA-256"); //genera un hash de 256
        byte[] key = pass.getBytes(StandardCharsets.UTF_8); //pasamos la clave a arreglo de bytes
        key = sha.digest(key); //generamos el hash
        return new SecretKeySpec(key, ALG);
    }


    //encripta/Desencripta ficheros
    private static void doCrypto(int cipherMode, SecretKeySpec key, File inputFile, File outputFile) {
        try {
            //Key secretKey = new SecretKeySpec(key.getBytes(), ALGORITHM);
            Cipher cipher = Cipher.getInstance(ALG);
            cipher.init(cipherMode, key);

            FileInputStream inputStream = new FileInputStream(inputFile);
            byte[] inputBytes = new byte[(int) inputFile.length()];
            inputStream.read(inputBytes);

            byte[] outputBytes = cipher.doFinal(inputBytes);

            FileOutputStream outputStream = new FileOutputStream(outputFile);
            outputStream.write(outputBytes);

            inputStream.close();
            outputStream.close();

        } catch (Exception e) {
            msgY("Error encrypting/decrypting file: "+ e);

        }

    }


    // FIN => FUNCIONES DE CIFRADO Y DESCIFRADO ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::



    //Chequea si existe una dirección de BD y un pass almacenados
    public  static Boolean checkGVar(){
        return !UtilsY.G_patBD.isEmpty() && !UtilsY.pass.isEmpty();
    }

    //Devuelve la BD de Android en un fichero encriptado con la clave (dentro el contenido esta en español)
    public  static String exportBD(String pass,String pathFile) throws Exception {

        JIniFile ini = new JIniFile(pathFile);
        JIniFile inif = new JIniFile(pathFile+"_out.txt");
        ArrayList<String> arraysections; //lista de secciones
        ArrayList<String> arraykeys;    //Lista de keys de una sección
        String section;            //almacena el valor de la seccion es español
        String value;              //Almacena el value

        //recorriendo el ini

        arraysections = ini.ReadSections(); // Obteniendo lista de secciones

        for (int i = 0; i < arraysections.size(); i++){ //recorriendo las secciones

            section = desencriptarY(arraysections.get(i),pass); //obtiene el nombre de la sección

            arraykeys = ini.ReadSection(arraysections.get(i)); //obteniendo lista de keys

            if (arraykeys.size() == 0){ //si no hay keys escribe la seccion y par key=value por defecto

                inif.WriteString(section,"key","value"); //ESCRIBIENDO!!!
                inif.UpdateFile();
            }else{ //si existe keys para la sección las recorre y escribe en el inif

                for (int ii = 0; ii < arraykeys.size(); ii++){ //recorriendo la lista de keys
                    value =  ini.ReadString(arraysections.get(i),arraykeys.get(ii),""); //Obteniendo el valor
                    if (value.isEmpty()){ //si el value esta vacio
                        inif.WriteString(section, desencriptarY(arraysections.get(i),pass),"" );
                        inif.UpdateFile();
                    }else{ //si existe algun value para la key
                        inif.WriteString(section, desencriptarY(arraysections.get(i),pass), desencriptarY(value,pass) );
                        inif.UpdateFile();
                    }
                }//for keys

            }

        }//for secciones

        encryptFile(pass,pathFile+"_out.txt",pathFile+"_out.txt" ) ;

        return "OK";
    }


    //muestra un mensaje (para propositos de debug)
    public  static void msgY(String message){

    Toast.makeText(G_context, message, Toast.LENGTH_LONG).show();
}



    //Renombra una entrada (Devuelve true si realizo bien la operación)
    public static boolean renEnt(String oldEntP, String newEntP) {
      try {
          // input the file content to the StringBuffer "input"
          BufferedReader file = new BufferedReader(new FileReader(G_patBD));
          StringBuffer inputBuffer = new StringBuffer(); //almacena el contenido del fichero
          String line;
          String entradaEnc = encriptarY(oldEntP, pass);
          String newEntEnc = encriptarY(newEntP, pass);

          while ((line = file.readLine()) != null) {
              inputBuffer.append(line);
              inputBuffer.append('\n');
          }
          file.close();
          String inputStr = inputBuffer.toString(); //Pasando el contenido a  cadena
          //Reemplazando el contenido
          inputStr =  inputStr.replace(entradaEnc+"=",newEntEnc+"=" );


          // Reescribiendo el contenido de nuevo
          FileOutputStream fileOut = new FileOutputStream(G_patBD);
          fileOut.write(inputStr.getBytes());
          fileOut.close();
          return  true;

      } catch (Exception e) {
          return false;
      }
  }




    //Funcion para  obtener la ruta de un fichero, dado su URI(Utilizado en los dialogos de busqueda de files):
    private static Uri contentUri = null;
    @SuppressLint("NewApi")
    public static String getPathFromUri(final Context context, final Uri uri) {
        // check here to is it KITKAT or new version
        final boolean isKitKatOrAbove = Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT;
        String selection;
        String[] selectionArgs;
        // DocumentProvider
        if (isKitKatOrAbove && DocumentsContract.isDocumentUri(context, uri)) {
            // ExternalStorageProvider
            if (isExternalStorageDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];

                String fullPath = getPathFromExtSD(split);
                if (!fullPath.equals("")) {
                    return fullPath;
                } else {
                    return null;
                }
            }

            // DownloadsProvider
            else if (isDownloadsDocument(uri)) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    final String id;
                    Cursor cursor = null;
                    try {
                        cursor = context.getContentResolver().query(uri, new String[]{MediaStore.MediaColumns.DISPLAY_NAME}, null, null, null);
                        if (cursor != null && cursor.moveToFirst()) {
                            String fileName = cursor.getString(0);
                            String path = Environment.getExternalStorageDirectory().toString() + "/Download/" + fileName;
                            if (!TextUtils.isEmpty(path)) {
                                return path;
                            }
                        }
                    } finally {
                        if (cursor != null)
                            cursor.close();
                    }
                    id = DocumentsContract.getDocumentId(uri);
                    if (!TextUtils.isEmpty(id)) {
                        if (id.startsWith("raw:")) {
                            return id.replaceFirst("raw:", "");
                        }
                        String[] contentUriPrefixesToTry = new String[]{
                                "content://downloads/public_downloads",
                                "content://downloads/my_downloads"
                        };
                        for (String contentUriPrefix : contentUriPrefixesToTry) {
                            try {
                                final Uri contentUri = ContentUris.withAppendedId(Uri.parse(contentUriPrefix), Long.parseLong(id));

                                return getDataColumn(context, contentUri, null, null);
                            } catch (NumberFormatException e) {
                                //In Android 8 and Android P the id is not a number
                                return uri.getPath().replaceFirst("^/document/raw:", "").replaceFirst("^raw:", "");
                            }
                        }
                    }

                } else {
                    final String id = DocumentsContract.getDocumentId(uri);
                    if (id.startsWith("raw:")) {
                        return id.replaceFirst("raw:", "");
                    }
                    try {
                        contentUri = ContentUris.withAppendedId(
                                Uri.parse("content://downloads/public_downloads"), Long.parseLong(id));

                    } catch (NumberFormatException e) {
                        e.printStackTrace();
                    }
                    if (contentUri != null) {
                        return getDataColumn(context, contentUri, null, null);
                    }
                }
            }
            // MediaProvider
            else if (isMediaDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];
                Uri contentUri = null;
                if ("image".equals(type)) {
                    contentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                } else if ("video".equals(type)) {
                    contentUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                } else if ("audio".equals(type)) {
                    contentUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                }
                selection = "_id=?";
                selectionArgs = new String[]{split[1]};


                return getDataColumn(context, contentUri, selection,
                        selectionArgs);
            } else if (isGoogleDriveUri(uri)) {
                return getDriveFilePath(uri, context);
            }
        }
        else if ("content".equalsIgnoreCase(uri.getScheme())) {

            if (isGooglePhotosUri(uri)) {
                return uri.getLastPathSegment();
            }

            if (isGoogleDriveUri(uri)) {
                return getDriveFilePath(uri, context);
            }
            if( Build.VERSION.SDK_INT == Build.VERSION_CODES.N)
            {
                return getMediaFilePathForN(uri, context);
            }else
            {
                return getDataColumn(context, uri, null, null);
            }
        }
        // File
        else if ("file".equalsIgnoreCase(uri.getScheme())) {
            return uri.getPath();
        }
        return null;
    }

    private static boolean fileExists(String filePath) {
        File file = new File(filePath);

        return file.exists();
    }

    private static String getPathFromExtSD(String[] pathData) {
        final String type = pathData[0];
        final String relativePath = "/" + pathData[1];
        String fullPath;

        if ("primary".equalsIgnoreCase(type)) {
            fullPath = Environment.getExternalStorageDirectory() + relativePath;
            if (fileExists(fullPath)) {
                return fullPath;
            }
        }

        fullPath = System.getenv("SECONDARY_STORAGE") + relativePath;
        if (fileExists(fullPath)) {
            return fullPath;
        }

        fullPath = System.getenv("EXTERNAL_STORAGE") + relativePath;
        if (fileExists(fullPath)) {
            return fullPath;
        }

        return fullPath;
    }

    private static String getDriveFilePath(Uri uri, Context context) {
        Cursor returnCursor = context.getContentResolver().query(uri, null, null, null, null);

        int nameIndex = returnCursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
        int sizeIndex = returnCursor.getColumnIndex(OpenableColumns.SIZE);
        returnCursor.moveToFirst();
        String name = (returnCursor.getString(nameIndex));
        String size = (Long.toString(returnCursor.getLong(sizeIndex)));
        File file = new File(context.getCacheDir(), name);
        try {
            InputStream inputStream = context.getContentResolver().openInputStream(uri);
            FileOutputStream outputStream = new FileOutputStream(file);
            int read = 0;
            int maxBufferSize = 1 * 1024 * 1024;
            int bytesAvailable = inputStream.available();

            //int bufferSize = 1024;
            int bufferSize = Math.min(bytesAvailable, maxBufferSize);

            final byte[] buffers = new byte[bufferSize];
            while ((read = inputStream.read(buffers)) != -1) {
                outputStream.write(buffers, 0, read);
            }

            inputStream.close();
            outputStream.close();
        } catch (Exception e) {
           msgY( "Error: " + e);
        }
        return file.getPath();
    }

    private static String getMediaFilePathForN(Uri uri, Context context) {
        Uri returnUri = uri;
        Cursor returnCursor = context.getContentResolver().query(returnUri, null, null, null, null);

        int nameIndex = returnCursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
        int sizeIndex = returnCursor.getColumnIndex(OpenableColumns.SIZE);
        returnCursor.moveToFirst();
        String name = (returnCursor.getString(nameIndex));
        String size = (Long.toString(returnCursor.getLong(sizeIndex)));
        File file = new File(context.getFilesDir(), name);
        try {
            InputStream inputStream = context.getContentResolver().openInputStream(uri);
            FileOutputStream outputStream = new FileOutputStream(file);
            int read = 0;
            int maxBufferSize = 1 * 1024 * 1024;
            int bytesAvailable = inputStream.available();

            //int bufferSize = 1024;
            int bufferSize = Math.min(bytesAvailable, maxBufferSize);

            final byte[] buffers = new byte[bufferSize];
            while ((read = inputStream.read(buffers)) != -1) {
                outputStream.write(buffers, 0, read);
            }

            inputStream.close();
            outputStream.close();
        } catch (Exception e) {
            msgY( "error" + e);
        }
        return file.getPath();
    }


    private static String getDataColumn(Context context, Uri uri,
                                        String selection, String[] selectionArgs) {
        Cursor cursor = null;
        final String column = "_data";
        final String[] projection = {column};

        try {
            cursor = context.getContentResolver().query(uri, projection,
                    selection, selectionArgs, null);

            if (cursor != null && cursor.moveToFirst()) {
                final int index = cursor.getColumnIndexOrThrow(column);
                return cursor.getString(index);
            }
        } finally {
            if (cursor != null)
                cursor.close();
        }

        return null;
    }

    private static boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri.getAuthority());
    }

    private static boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri.getAuthority());
    }

    private static boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals(uri.getAuthority());
    }

    private static boolean isGooglePhotosUri(Uri uri) {
        return "com.google.android.apps.photos.content".equals(uri.getAuthority());
    }

    private static boolean isGoogleDriveUri(Uri uri) {
        return "com.google.android.apps.docs.storage".equals(uri.getAuthority()) || "com.google.android.apps.docs.storage.legacy".equals(uri.getAuthority());
    }

    // FIN DE LOS METODOS PARA ABRIR UN FICHERO

}//class
