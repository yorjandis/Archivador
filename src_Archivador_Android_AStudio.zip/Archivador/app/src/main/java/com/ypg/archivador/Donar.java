package com.ypg.archivador;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class Donar extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donar);

        Toolbar toolbar2 = (Toolbar) findViewById(R.id.toolbar2);
        setSupportActionBar(toolbar2);
        getSupportActionBar().setIcon(R.drawable.ic_toolbar_ico);

        ImageView paypalDonate = (ImageView) findViewById(R.id.adonar_imgpaypal);
        Button btnBack = (Button) findViewById(R.id.adonar_btn_back);

     btnBack.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
            Donar.super.onBackPressed();
         }
     });


        paypalDonate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               String  url = "https://paypal.me/Yorpg?locale.x=es_ES";
                Uri uri = Uri.parse(url);
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            }
        });


    }
}