package com.ypg.archivador;

import com.ypg.archivador.GUI.DialogSelectBDAndP;
import com.ypg.archivador.GUI.Tools;
import com.ypg.archivador.Util.Utils;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;

public class GUIMain extends  JFrame {
    private  JPanel rootPanel;
    public  JList list_Catg;
    private JButton btn_Add_Categ;
    private JButton btn_Del_Catg;
    private JList list_Entrada;
    private JButton btn_Del_Entrada;
    private JButton btn_Modif_Values;
    private JScrollPane scrollPane;
    private JTextArea edit_Values;
    private JPanel panelCatg;
    private JPanel panelEntradas;
    private JPanel panelValues;
    private JButton btn_Add_Entrada;
    //Elementos de barra de menu
    private JMenuBar menuBar;
    private JMenu m_archivo, m_tools, m_mostar; //menu de la barra de menu
        private JMenuItem mi_abrirBD;
        private JMenuItem mi_crearBD;
        private JMenuItem mi_ShowTools;
        private JMenuItem mi_salir;
        private JMenuItem mi_showhelp;
        private JMenuItem mi_creditos;


    public GUIMain() {
       // setResizable(false);
        setLocationRelativeTo( null );
        add(rootPanel);
        setSize(850,400);
        setTitle("Archivador V1.0");
        //Estableciendo algunas propiedades de elementos
        list_Catg.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list_Entrada.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        setLocation( Toolkit.getDefaultToolkit().getScreenSize().width/4,Toolkit.getDefaultToolkit().getScreenSize().height/4);



        //Construyendo el menu:
        menuBar     = new JMenuBar();
        m_archivo   = new JMenu("Archivo");
        m_tools     = new JMenu("Herramientas");
        m_mostar    = new JMenu("Mostrar");

        mi_abrirBD  = new JMenuItem("Abrir BD...");
        mi_crearBD  = new JMenuItem("Crear BD...");
        mi_salir    = new JMenuItem("Salir");

        mi_ShowTools = new JMenuItem("Mostrar Cuadro de Herramientas");


        mi_showhelp = new JMenuItem("Mostrar Ayuda");
        mi_creditos = new JMenuItem("Créditos");

        m_archivo.add(mi_abrirBD);
        m_archivo.add(mi_crearBD);
        m_archivo.add(mi_salir);

        m_tools.add(mi_ShowTools);

        m_mostar.add(mi_showhelp);
        m_mostar.add(mi_creditos);

        menuBar.add(m_archivo);
        menuBar.add(m_tools);
        menuBar.add(m_mostar);
        setJMenuBar(menuBar);


        //Lista de categoría OK
        list_Catg.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                edit_Values.setText(""); //reset
                DefaultListModel model = new DefaultListModel();
                model = Utils.loadEnt(list_Catg.getSelectedValue().toString());
                list_Entrada.setModel(model);
            }
        });

        //Lista de Entradas OK
        list_Entrada.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                edit_Values.setText(""); //reset
                String a;
              a =   Utils.loadEntvalues(list_Catg.getSelectedValue().toString(), list_Entrada.getSelectedValue().toString(),"");
                edit_Values.setText(a);
            }
        });

        //menu salir OK
        mi_salir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                System.exit(0);
            }
        });

        //menu abrir BD OK
        mi_abrirBD.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //mostrando la ventana para colocar los datos de BD y pass:
                DialogSelectBDAndP dialog = new DialogSelectBDAndP("Abrir la BD",GUIMain.this, true);
                dialog.setVisible(true);

                    DefaultListModel m = new DefaultListModel();
                    m = Utils.loadbd();
                    list_Catg.setModel(m);


            }
        });

        //menu Crear BD OK
        mi_crearBD.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                DialogSelectBDAndP dialog = new DialogSelectBDAndP("Crear una BD",GUIMain.this, false);
                dialog.setVisible(true);
                /*
                if (Utils.flags[0].contentEquals("S")){//Si todoo OK
                    try {
                        CrearBDY();
                    } catch (Exception exception) {
                        JOptionPane.showMessageDialog(GUIMain.this, "Error: "+ e);
                    }

                }*/
            }
        });

        //menu Tools
        mi_ShowTools.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Tools tt = new Tools();
                tt.setVisible(true);
            }
        });


        //boton Adicionar categoria OK
        btn_Add_Categ.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String catg = JOptionPane.showInputDialog("Coloque el nombre de la nueva Categoría").trim();

                if (catg.isEmpty()) { return; }

                if (!CheqString(list_Catg,catg)){ //si no tiene la categoria
                    if (!Utils.G_patBD.isEmpty()){ //si se ha cargado una BD
                       if (Utils.AddNewCatg(catg)) { //si la operación de adición se realizó correctamente
                          DefaultListModel model =  Utils.loadbd();
                          list_Catg.setModel(model);
                       }else{
                           JOptionPane.showMessageDialog(GUIMain.this,"Error: No se pudo adicionar la categoría");
                       }
                    }

                }else { //Si ya contiene una categoria
                    JOptionPane.showMessageDialog(null, "La categoría: <<"+ catg +">> ya existe.");
                }



        }
        });

        //Botón Eliminar Categoria OK
        btn_Del_Catg.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String a = list_Catg.getSelectedValue().toString(); //Obteniendo la categoria
                if(Utils.DelCateg(a)){ //viendo si se hizo todo okook
                  DefaultListModel model =   Utils.loadbd();
                  list_Catg.setModel(model);
                }else{
                    JOptionPane.showMessageDialog(GUIMain.this, "Error: No se eliminó la categoría");
                }
            }
        });

        //Botón Adicionar nueva Entrada OK
        btn_Add_Entrada.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String entr = JOptionPane.showInputDialog("Coloque el nombre de la nueva Categoría").trim();

                if (entr.isEmpty()) { return; }

                if (!CheqString(list_Entrada,entr)){ //si no tiene la categoria{}
                    Utils.AddNewEnt(list_Catg.getSelectedValue().toString(),entr,"ValorEjemplo");
                   //actualizando la lista de entradas:
                    list_Entrada.setModel(Utils.loadEnt(list_Catg.getSelectedValue().toString()));

                }else{
                    JOptionPane.showMessageDialog(GUIMain.this,"Error: No se pudo adicionar la entrada");
                }




            }
        });

        //Botón Eliminar una entrada OK
        btn_Del_Entrada.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                if(Utils.DelEnt(list_Catg.getSelectedValue().toString(), list_Entrada.getSelectedValue().toString())){
                    JOptionPane.showMessageDialog(null,"La Entrada: ha sido removida correctamente");
                    //actualizando la lista de entradas:
                    list_Entrada.setModel(Utils.loadEnt(list_Catg.getSelectedValue().toString()));
                }else{
                    JOptionPane.showMessageDialog(null,"Error: La entrada  no se ha removido");
                }


            }
        });

        //Botón Modificar el valor de una entrada OK
        btn_Modif_Values.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
             if(Utils.ModEnt(list_Catg.getSelectedValue().toString(), list_Entrada.getSelectedValue().toString(),edit_Values.getText().replaceAll("[\r\n]", "%/"))) {
                 //Actualizando los controles
                 edit_Values.setText(""); //reset
                 String a;
                 a =   Utils.loadEntvalues(list_Catg.getSelectedValue().toString(), list_Entrada.getSelectedValue().toString(),"");
                 edit_Values.setText(a);
             }else{
                 JOptionPane.showMessageDialog(null,"Error: La entrada  no se ha modificado");
             }
            }
        });
    }



    // FUNCIONES INTERNAS ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::



    //Limpia todos los campos de la BD
    public static void ClearGUI(JList listaCatg, JList ListEntra, JTextArea editvalues) {

        DefaultListModel listModel = new DefaultListModel();

        listModel = (DefaultListModel) listaCatg.getModel();
        listModel.removeAllElements();

        listModel = (DefaultListModel) ListEntra.getModel();
        listModel.removeAllElements();
        editvalues.setText("");
    }

    
    //función que crea la base de datos en la raíz de la memmoria. No la carga en la GUI
    private  void CrearBDY() throws Exception {
        //Crear el fichero en la memoria

                String pathfile = Utils.G_patBD;
                String pass = Utils.pass;

                //Lista de Categorias por defecto a adicionar (Ya encriptadas)
                List<String> CatgDefault = new ArrayList<String>();
                CatgDefault.add("[" + Utils.encriptarY("NOTAS",pass)        + "]");
                CatgDefault.add("[" + Utils.encriptarY("IDENTIDAD",pass)    + "]");
                CatgDefault.add("[" + Utils.encriptarY("BANCOS",pass)       + "]");
                CatgDefault.add("[" + Utils.encriptarY("CONTRASEÑAS",pass)  + "]");
                CatgDefault.add("[" + Utils.encriptarY("FINANZAS",pass)     + "]");
                CatgDefault.add("[" + Utils.encriptarY("WEBS",pass)         + "]");

                //Creando y Chequeando que el nuevo fichero a crear
                try {
                    File file = new File(pathfile);
                    if (!file.exists()) { //Si el fichero no existe en memoria
                        file.createNewFile();

                        try {
                            OutputStreamWriter write = null;
                            write = new OutputStreamWriter(new FileOutputStream(file));

                            for (int i = 0; i < CatgDefault.size(); i++){
                                write.write(CatgDefault.get(i) + "\n" );
                            }

                            write.close(); //escribe los valores y cierra el fichero
                            JOptionPane.showMessageDialog(GUIMain.this,"Se creó correctamente la BD");

                        }catch (Exception e){
                            JOptionPane.showMessageDialog(GUIMain.this,"Error:"+ e);
                        }


                    }else{ //Si ya existe un fichero con el mismo nombre en la ubicación
                        JOptionPane.showMessageDialog(GUIMain.this,"El nombre dado corresponde a un fichero ya en uso");
                    }
                } catch (Exception e){
                    JOptionPane.showMessageDialog(GUIMain.this,"Error:"+ e);
                }






    }



    //Chequea si un Jlist contiene una cadena ok
    private boolean CheqString(JList listp, String newString){
        //pasando el Jlist a un objeto  list
        List<String> list = new ArrayList<String>(listp.getModel().getSize());
        for (int i = 0; i < listp.getModel().getSize(); i++) {
            if (listp.getModel().getElementAt(i).toString().toLowerCase().contentEquals(newString.toLowerCase())){
           return true;
            }
        }
       return false;
    }
    
    
}//class
