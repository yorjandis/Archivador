package com.ypg.archivador;

public class Main {

    public static void main(String[] args) {

        GUIMain yy = new GUIMain();

        yy.setVisible(true);

    }
}
