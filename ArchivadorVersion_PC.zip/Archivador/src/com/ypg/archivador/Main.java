package com.ypg.archivador;

import javax.swing.*;


public class Main {

    public static void main(String[] args) {



        GUIMain yy = new GUIMain();
        yy.setVisible(true);

        JOptionPane.showMessageDialog(null, "Las BD anteriores a la version 1.1.1 en PC y 1.2.9 en Android app \n" +
                                                                    "no son compatibles con el nuevo algoritmo de AES/CGM. Para migrar su BD \n " +
                                                                     "al nuevo cifrado instale la versión Android y utilice el asistente de migración \n" +
                                                                     "en el menú superior.");

    }
}
