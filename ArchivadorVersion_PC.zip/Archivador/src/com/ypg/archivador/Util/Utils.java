package com.ypg.archivador.Util;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.swing.*;
import java.io.*;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.logging.Logger;


public class Utils {

    //Variables Globales
    private static final String ALG = "AES"; //Algoritmo utilizado
    private static final String ALG_Cipher = "AES/GCM/NoPadding"; //Algoritmo de encriptamiento
    private static byte[] G_iv = new byte[12]; // vector de inicialización nonce


    public static String G_patBD = "";              //almacena la ruta del archivo actual de la BD (se modifica en f_AbrirBD.java)
    public  static  String pass = "";               //Almacena la clave actual de cifrado/descifrado dada por el usuario.
    public static  Logger logger = null;
    public static String ListCatItemActual = "";     //Almacena la categoria actual seleccionada(para actualización de values)
    public static String ListEntItemActual = "";     //Almacena la entrada  actual seleccionada(para actualización de values)


   // public  static String[] flags = new String[3]; //almacena valores flotantes
    public static boolean isBDOpenEnc = false;      //Almacena true, si la BD se desencriptó al abrir
    public static boolean isBDOpenEncMismaPass = false; //si al abrir la base de datos esta se descriptó con la misma clave de cifrado
    public static String passEncripted = "";        //Almacena la clave de escriptación actual
    public static boolean isModifyValue = false; //establece si se ha modificado el edit de los Values

//FUNCIONES GNERALES ::::::::::::::::::::::::::::::::::::::



//FUNCIONES fichero INI::::::::::::::::


    //función que crea la base de datos en la raíz de la memmoria. No la carga en la GUI
    public  static boolean crearBDY(String pathBDP, String passP) throws Exception {
        //Crear el fichero en la memoria

        //Lista de Categorias por defecto a adicionar (Ya encriptadas)
        List<String> CatgDefault = new ArrayList<>();
        CatgDefault.add("[" + encriptarY("NOTAS", passP)        + "]");
        CatgDefault.add("[" + encriptarY("IDENTIDAD", passP)    + "]");
        CatgDefault.add("[" + encriptarY("BANCOS", passP)       + "]");
        CatgDefault.add("[" + encriptarY("CONTRASEÑAS", passP)  + "]");
        CatgDefault.add("[" + encriptarY("FINANZAS", passP)     + "]");
        CatgDefault.add("[" + encriptarY("WEBS", passP)         + "]");

        //Creando y Chequeando que el nuevo fichero a crear
        try {
            File file = new File(pathBDP);

            try {
                OutputStreamWriter write;
                write = new OutputStreamWriter(new FileOutputStream(file));

                for (int i = 0; i < CatgDefault.size(); i++){
                    write.write(CatgDefault.get(i) + "\n" );
                }

                write.close(); //escribe los valores y cierra el fichero
                return true;
            }catch (Exception e){
                return  false;
            }

        } catch (Exception e){
            return  false;
        }

    }


    //Devuelve la lista de categorias de la BD
    public  static DefaultListModel loadbd(){
        //File inifile = new File(Environment.getExternalStorageDirectory() + "/yorjj.txt");

        DefaultListModel<String> model = new DefaultListModel<String>();

        if ( G_patBD == "" || !new File(G_patBD).exists()){ return model;} //No carga la BD

        try {
            JIniFile ini = new JIniFile(Utils.G_patBD);
            ArrayList<String> sections =  ini.ReadSections(); //Obteniendo todas las secciones

            if (sections.size() > 0) { //si existen secciones que cargar
                //recorriendo las secciones para descifrarlas

                for (int i = 0; i < sections.size(); i++){
                    model.addElement(desencriptarY(sections.get(i), pass));
                }
                return model;

            }else{
                JOptionPane.showMessageDialog(null,"El fichero de BD esta vacio");
            }

        }catch (Exception e){
            logger.info("Error: "+ e);
        }

        return  model;
    }


    //Devuelve las entradas para una Categoria Dada
    public static DefaultListModel loadEnt(String Catg){
        DefaultListModel<String> model = new DefaultListModel<String>();
        try{
            JIniFile ini = new JIniFile(G_patBD);
            ArrayList<String> list = ini.ReadSection(encriptarY(Catg,pass)); //Obteniendo todas las keys de una sección

            if (list.size() > 0) { //si existen entradas que cargar
                //recorriendo las secciones para descifrarlas

                for (int i = 0; i < list.size(); i++){
                    model.addElement(desencriptarY(list.get(i), pass));
                }

                return model;

            }else{//Si no hay entradas que cargar se elimina todas las entradas del control
                list.clear();
            }


        }catch (Exception e){
            logger.info("Error: " + e);
        }

        return model;
    }

    //Devuelve el contenido de una entrada OK
    public static String loadEntvalues(String Catg, String Ent, String ValueDefault){
        String resul = "";

        try{
            JIniFile ini = new JIniFile(G_patBD);
            resul = desencriptarY(ini.ReadString(encriptarY(Catg,pass),encriptarY(Ent,pass),ValueDefault),pass);
        }catch (Exception e){
            logger.info("Error: " + e);
        }

        resul =  resul.replaceAll("%/", "\n");
        return resul;
    }

    //Adicionar nueva Categoria a la BD OK
    public static Boolean AddNewCatg(String catg){

        Boolean resul = false;
        try{
            JIniFile ini = new JIniFile(Utils.G_patBD);
            ini.WriteString(encriptarY(catg,pass),encriptarY("EntEjemplo",pass), encriptarY("ValorEjemplo",pass));
             ini.UpdateFile();
              resul = true;
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,"Error: "+ e);
        }

        return  resul;
    } //AddNewCatg


    //Eliminar una Categoria de la BD OK
    public static Boolean DelCateg(String Catg){
        Boolean resul = false;
        if ( G_patBD == "" || !new File(G_patBD).exists()){ return resul;} //No carga la BD
        try {
            JIniFile ini = new JIniFile(G_patBD);
            ini.EraseSection(encriptarY(Catg,pass));
            if (ini.UpdateFile()){
                resul = true;
            }else{                   //error con ini.UpdateFile()
                resul = false;
            }
        }catch (Exception e){
            logger.info("Error: " + e);
        }
        return resul;
    }

    //Elimina una entrada (key) de una categoría dada
    public static Boolean DelEnt(String Catg, String Ent){
        Boolean resul = false;

        try{
            JIniFile ini = new JIniFile(G_patBD);
            ini.DeleteKey(encriptarY(Catg,pass),encriptarY(Ent,pass));
            if (ini.UpdateFile()){
                resul = true;
            }else{
                resul = false;
            }
        }catch (Exception e){
            logger.info("Error: "+ e);
        }
        return resul;
    }

    //Adiciona una nueva entrada en una categoría dada OK
    public static Boolean AddNewEnt(String Catg, String NewEnt, String NewValueDefault){
        Boolean resul = false;
        try{

            JIniFile ini = new JIniFile(G_patBD);
            ini.WriteString(encriptarY(Catg,pass), encriptarY(NewEnt, pass),encriptarY(NewValueDefault,pass));
            if (ini.UpdateFile()){
                resul = true;
            }else{
                resul = false;
            }
        }catch (Exception e){
            logger.info("Error: " + e);
        }

        return resul;
    }

    //Modifica el valor de una entrada
    public static Boolean ModEnt(String Catg, String Ent, String ValueDefault){
        Boolean resul = false;
        try{
            JIniFile ini = new JIniFile(G_patBD);
            ini.WriteString(encriptarY(Catg,pass), encriptarY(Ent, pass),encriptarY(ValueDefault,pass));
            if (ini.UpdateFile()){
                resul = true;
            }else{
                resul = false;
            }
        }catch (Exception e){
            JOptionPane.showMessageDialog(null,"Error: " + e );
        }

        return resul;
    }

    //Función útil: determina si existe una categoria ya en el fichero INI
    public static boolean containCatginIni(String Catg){

        Boolean resul = false;
        if ( G_patBD == "" || !new File(G_patBD).exists()){ return resul;} //No carga la BD


        try {
            JIniFile ini = new JIniFile(G_patBD);
            ArrayList<String> sections = ini.ReadSections(); //Obteniendo todas las secciones

            for (int i= 0; i < sections.size(); i++){
                if (desencriptarY(sections.get(i), pass).equalsIgnoreCase(Catg)){
                    return  true;
                }
            }
        }catch (Exception e){
            logger.info("YY"+e);
        }
        return resul;
    }


    // FUNCIONES DE CIFRADO Y DESCIFRADO :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

    //Genera una Secrekey A partir de una clave dada por el usuario
    private static SecretKeySpec generarkeyY(String pass) throws Exception {
        MessageDigest sha = MessageDigest.getInstance("SHA-256"); //genera un hash de 256
        byte[] key = pass.getBytes(StandardCharsets.UTF_8); //pasamos la clave a arreglo de bytes
        key = sha.digest(key); //generamos el hash
        return new SecretKeySpec(key, ALG);
    }


    //Cifrar un texto
    public static String Old_encriptarY(String txtToEncode, String pass) throws Exception {

        SecretKeySpec secretKeySpec = generarkeyY(pass);
        Cipher cipher = Cipher.getInstance(ALG);
        cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec);
        byte[] datosencriptados = cipher.doFinal(txtToEncode.getBytes());
        String datos = Base64.getUrlEncoder().withoutPadding().encodeToString(datosencriptados);
        //String datos = Base64.encodeToString(datosencriptados, Base64.URL_SAFE + Base64.NO_PADDING);
        datos = datos.replace("\n", ""); //quitando los saltos de linea
        return datos;
    }

    //Descifrar un texto
    public static String Old_desencriptarY(String txtToDecode, String pass) throws Exception {
        SecretKeySpec secretKeySpec = generarkeyY(pass);
        Cipher cipher = Cipher.getInstance(ALG);
        cipher.init(Cipher.DECRYPT_MODE, secretKeySpec);
        byte[] datosdesencriptados = Base64.getUrlDecoder().decode(txtToDecode);
        //byte[] datosdesencriptados = Base64.decode(txten,Base64.URL_SAFE + Base64.NO_PADDING);
        byte[] datos = cipher.doFinal(datosdesencriptados);
        String resul = new String(datos);
        resul = resul.replace("\n", "");//quitando los saltos de linea
        return resul;
    }


    //////nuevas funciones par encriptamiento////

    //cifrar una cadena de texto
    public static String encriptarY(String txtToDecode, String pass) throws Exception {

        byte[] result; //Resultado final (arreglo de bytes)
        String resultFinal = "";

        ////////////////Yor: estas dos  lineas tienen el objetivo de crear un vector de inicializacion  IV distinto en cada caso
        ////////////////Pero tiene el invonveniente de generar una cadena cifrada distinta cada vez que se cifra
        //Prepare the nonce
        //SecureRandom secureRandom = new SecureRandom();
        //Noonce should be 12 bytes
        // secureRandom.nextBytes(G_iv);
        /////////////////////////////////////////////////////////


        G_iv = "r8ei#JTFS5*G".getBytes(StandardCharsets.UTF_8);  //Utilizando un vector de inicialización fijo (crea más vulnerabilidad pero hace que funcione)

        //Prepare your key/password
        SecretKey secretKey =  generarkeyY(pass); // generateSecretKey(pass, G_iv);


        Cipher cipher = Cipher.getInstance(ALG_Cipher);
        GCMParameterSpec parameterSpec = new GCMParameterSpec(128, G_iv);

        //Encryption mode on!
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, parameterSpec);

        //Encrypt the data
        byte [] encryptedData = cipher.doFinal(txtToDecode.getBytes(StandardCharsets.UTF_8));

        //Concatenate everything and return the final data
        ByteBuffer byteBuffer = ByteBuffer.allocate(4 + G_iv.length + encryptedData.length);
        byteBuffer.putInt(G_iv.length);
        byteBuffer.put(G_iv);
        byteBuffer.put(encryptedData);

        result = byteBuffer.array();
        resultFinal = Base64.getUrlEncoder().withoutPadding().encodeToString(result);
        resultFinal = resultFinal.replace("\n", "");//quitando los saltos de linea

        //Convertir a cadena de texto plano codificada
        return resultFinal;
    }

    //descifrar una cadena de texto
    public static String desencriptarY( String txtToDecode, String pass)
            throws Exception{

        //Pasando el texto de entrada a bytes para que pueda ser leído correctamente
        byte[] txtADec = Base64.getUrlDecoder().decode(txtToDecode);

        byte[] result; //Resultado final (arreglo de bytes)
        String resultFinal = "";

        //Wrap the data into a byte buffer to ease the reading process
        ByteBuffer byteBuffer = ByteBuffer.wrap(txtADec);

        int noonceSize = byteBuffer.getInt();

        //Make sure that the file was encrypted properly
        if(noonceSize < 12 || noonceSize >= 16) {
            JOptionPane.showMessageDialog(null,"Error. Es posible que contenido no este cifrado");
        }
        byte[] iv = new byte[noonceSize];
        byteBuffer.get(iv);

        //Prepare your key/password
        SecretKey secretKey =  generarkeyY(pass); //generateSecretKey(pass, iv);

        //get the rest of encrypted data
        byte[] cipherBytes = new byte[byteBuffer.remaining()];
        byteBuffer.get(cipherBytes);

        Cipher cipher = Cipher.getInstance(ALG_Cipher);
        GCMParameterSpec parameterSpec = new GCMParameterSpec(128, iv);

        //Encryption mode on!
        cipher.init(Cipher.DECRYPT_MODE, secretKey, parameterSpec);

        //Encrypt the data
        result = cipher.doFinal(cipherBytes);
        resultFinal = new String(result,StandardCharsets.UTF_8);
        // resultFinal = resultFinal.replace("\n", "");//quitando los saltos de linea

        return resultFinal;

    }



    /////// Fin ////////


    //encriptar un fichero
    public static Boolean encryptFile(String key, String inputFilea, String outputFilea) {
        try {
            SecretKeySpec secretKeySpec = generarkeyY(key);
            File inputFile = new File(inputFilea); //fichero de entrada
            File outputFile = new File(outputFilea); //fichero de salida (encriptado)
            doCrypto(Cipher.ENCRYPT_MODE, secretKeySpec, inputFile, outputFile);
            return true;
        }catch (Exception e){
            return false;
        }
    }

    //desencriptar un fichero
    public static Boolean decryptFile(String key, String inputFilea, String outputFilea) {
        try{
            SecretKeySpec secretKeySpec = generarkeyY(key);
            File inputFile = new File(inputFilea); //fichero de entrada (encriptado)
            File outputFile = new File(outputFilea); //fichero de salida
            doCrypto(Cipher.DECRYPT_MODE, secretKeySpec, inputFile, outputFile);
            return true;
        }catch (Exception e){
            return false;
        }
    }

    //calcula y devuelbe  el hash de un fichero.
    public static String hashFile(String filepath, String alg) throws IOException, NoSuchAlgorithmException {
        // Set your algorithm
        // "MD2","MD5","SHA","SHA-1","SHA-256","SHA-384","SHA-512"

        File file = new File(filepath);

        if (file.exists()){
            MessageDigest md = MessageDigest.getInstance(alg); //el parametro alg contiene el algoritmo a utilizar
            FileInputStream fis = new FileInputStream(file);
            byte[] dataBytes = new byte[1024];

            int nread;
            while ((nread = fis.read(dataBytes)) != -1) {
                md.update(dataBytes, 0, nread);
            }

            byte[] mdbytes = md.digest();

            StringBuilder sb = new StringBuilder();
            for (byte mdbyte : mdbytes) {
                sb.append(Integer.toString((mdbyte & 0xff) + 0x100, 16).substring(1));
            }
            return sb.toString();
        }
        return "";

    }

    //Comprueba el hash de un fichero
    public static Boolean hashFileCheck(String filePath, String hashAlg, String hash) {

        try {
            String s =  hashFile(filePath,hashAlg);
            if (s.contentEquals(hash)){
                return  true; //el hash coincide
            }else{
                return false;
            }
        } catch (Exception e) {
            System.out.print("Error: "+ e);
        }
        return false;
    }

    //Calcula el hash de un texto
    public static String hashText(String text, String alghash){
        byte[] hash = null;
        try {
            MessageDigest md = MessageDigest.getInstance(alghash);
            hash = md.digest(text.getBytes());

        } catch (NoSuchAlgorithmException e) { e.printStackTrace(); }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < hash.length; ++i) {
            String hex = Integer.toHexString(hash[i]);
            if (hex.length() == 1) {
                sb.append(0);
                sb.append(hex.charAt(hex.length() - 1));
            } else {
                sb.append(hex.substring(hex.length() - 2));
            }
        }
        return sb.toString();
    }

    //Comprueba el hash de un texto
    public static Boolean hashTextCheck(String text, String hash, String alg){
        String temp = hashText(text,alg);
        if(temp.equals(hash)){
            return true;
        }
        return false;
    }

    //Devuelve la BD de Android en un fichero encriptado con la clave (dentro el contenido esta en español)
    public  static String exportBD(String pass,String pathFile) throws Exception {

        JIniFile ini = new JIniFile(pathFile);
        JIniFile inif = new JIniFile(pathFile+"_out.txt");
        ArrayList<String> arraysections; //lista de secciones
        ArrayList<String> arraykeys;    //Lista de keys de una sección
        String section = "";            //almacena el valor de la seccion es español
        String value = "";              //Almacena el value

        //recorriendo el ini

        arraysections = ini.ReadSections(); // Obteniendo lista de secciones

        for (int i = 0; i < arraysections.size(); i++){ //recorriendo las secciones

            section = desencriptarY(arraysections.get(i),pass); //obtiene el nombre de la sección

            arraykeys = ini.ReadSection(arraysections.get(i)); //obteniendo lista de keys

            if (arraykeys.size() == 0){ //si no hay keys escribe la seccion y par key=value por defecto

                inif.WriteString(section,"key","value"); //ESCRIBIENDO!!!
                inif.UpdateFile();
            }else{ //si existe keys para la sección las recorre y escribe en el inif

                for (int ii = 0; ii < arraykeys.size(); ii++){ //recorriendo la lista de keys
                    value =  ini.ReadString(arraysections.get(i),arraykeys.get(ii),""); //Obteniendo el valor
                    if (value.isEmpty()){ //si el value esta vacio
                        inif.WriteString(section, desencriptarY(arraysections.get(i),pass),"" );
                        inif.UpdateFile();
                    }else{ //si existe algun value para la key
                        inif.WriteString(section, desencriptarY(arraysections.get(i),pass), desencriptarY(value,pass) );
                        inif.UpdateFile();
                    }
                }//for keys

            }

        }//for secciones

        encryptFile(pass,pathFile+"_out.txt",pathFile+"_out.txt" ) ;

        return "OK";
    }




    //encripta/Desencripta ficheros
    private static void doCrypto(int cipherMode, SecretKeySpec key, File inputFile, File outputFile) {
        try {
            //Key secretKey = new SecretKeySpec(key.getBytes(), ALGORITHM);
            Cipher cipher = Cipher.getInstance(ALG);
            cipher.init(cipherMode, key);

            FileInputStream inputStream = new FileInputStream(inputFile);
            byte[] inputBytes = new byte[(int) inputFile.length()];
            inputStream.read(inputBytes);

            byte[] outputBytes = cipher.doFinal(inputBytes);

            FileOutputStream outputStream = new FileOutputStream(outputFile);
            outputStream.write(outputBytes);

            inputStream.close();
            outputStream.close();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Error encrypting/decrypting file: "+ e);

        }

    }


    //Chequea si existe una dirección de BD y un pass almacenados
    public  static Boolean CheckGVar(){
        if(!Utils.G_patBD.isEmpty() && !Utils.pass.isEmpty()){
            return  true;
        }
     return  false;
    }

}
