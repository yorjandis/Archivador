package com.ypg.archivador.GUI;

import com.ypg.archivador.GUIMain;
import com.ypg.archivador.Util.Utils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

// Construye una ventana modal para que el usuario coloque dirección de BD y Contraseña
// flag = true (Abrir BD: Actualiza las variables de pathBD y pass en Utils class)
// flag = false (Crear BD: no modifica las variables pathBD y pass en Utils. crear la BD silenciosamente)

public class DialogSelectBDAndP {

    private JDialog dialog;
    private JTextField textField;
    static Boolean flagG;

    //Constructor del dialogo
    public DialogSelectBDAndP(String title, JFrame parent, Boolean flag){
        dialog = new JDialog(parent, title, true);
        dialog.setDefaultCloseOperation(JDialog.HIDE_ON_CLOSE);
        flagG = flag;
        init();
    }
    //Para mostrar [ocultar] la ventana
    public void setVisible(Boolean flag){
        dialog.setVisible(flag);
    }

    //Construye la ventana y sus componentes
    private void init(){
        JLabel label_text1 = new JLabel("Seleccione la ruta de la BD");
        JLabel label_text2 = new JLabel("Coloque la contraseña de la BD (No debe contener espacios");
        JTextField inputbrowse      = new JTextField(); //campo para la dirección de la BD
        if (flagG){ //Si Abrir BD
            inputbrowse.setEnabled(false);
        }else{
            inputbrowse.setEnabled(true);
        }
        JPasswordField inputpass    = new JPasswordField(); //campo para el pass de la BD
        JButton btn_Browse  = new JButton("Buscar");
        JButton btn_OK      = new JButton("OK");
        JButton btn_Cancel  = new JButton("Cancelar");
        JCheckBox checkBox_isEcrBD = new JCheckBox("la BD esta encriptada");
        JCheckBox checkBox_mismopass = new JCheckBox("Utiliza la misma contraseña de cifrado");
        JPasswordField text_passEnc = new JPasswordField(); //campo para la contraseña se encriptado

        checkBox_mismopass.setVisible(false);
        text_passEnc.setVisible(false);

        dialog.add(label_text1);
        dialog.add(label_text2);
        dialog.add(inputbrowse);
        dialog.add(inputpass);
        dialog.add(btn_Browse);
        dialog.add(checkBox_isEcrBD);
        dialog.add(checkBox_mismopass);
        dialog.add(text_passEnc);
        dialog.add(btn_OK);
        dialog.add(btn_Cancel);
        dialog.setPreferredSize(new Dimension(470,300));

        label_text1.setBounds(10,5,250,17);
        inputbrowse.setBounds(10,25,350,25);
        label_text2.setBounds(10,60,250,17);
        inputpass.setBounds(10,78,350,25);
        btn_Browse.setBounds(370,20,80,30);
        checkBox_isEcrBD.setBounds(10,120,150,27);
        checkBox_mismopass.setBounds(30, 150,250,27);
        text_passEnc.setBounds(40,180,250,27);

        btn_OK.setBounds(110,220,80,30);
        btn_Cancel.setBounds(220,220,80,30);
        dialog.setLayout(null);
        dialog.setLocationRelativeTo(null);
        dialog.pack();

        //Eventos de los checks:
            //check BD encriptada
        checkBox_isEcrBD.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(checkBox_isEcrBD.isSelected()) {
                    checkBox_mismopass.setVisible(true);
                    checkBox_mismopass.setSelected(true);

                }else{
                    checkBox_mismopass.setVisible(false);
                   text_passEnc.setVisible(false);
                   text_passEnc.setText("");
                }
            }
        });

            //check mismo pass
        checkBox_mismopass.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(checkBox_mismopass.isSelected()){
                    text_passEnc.setVisible(false);
                }else{
                    text_passEnc.setVisible(true);
                }
            }
        });



        //Botón browser
        btn_Browse.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                String fileName;

                int returnVal = fileChooser.showOpenDialog(dialog);
                //Botón de aprobación
                if (returnVal == JFileChooser.APPROVE_OPTION) {
                    File file = fileChooser.getSelectedFile();
                    try {
                        fileName = file.toString();
                        if (flagG) { //Abrir
                            if (file.exists()) { //si existe el fichero de BD
                                inputbrowse.setText(fileName);
                            }else{//El fichero no existe en la memoria
                                JOptionPane.showMessageDialog(dialog, "El fichero no existe");
                                inputbrowse.setText("");
                            }
                        }else{//si es crearBD (No hace la comprobación de si existe el fichero)
                            inputbrowse.setText(fileName);
                        }

                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(dialog, "No se pudo acceder al fichero");
                        inputbrowse.setText("");
                    }
                }
                //boton cancelar del filechooser dialog
                if (returnVal == JFileChooser.CANCEL_OPTION) {
                    inputbrowse.setText("");
                }

            }
        });

        //Boton OK
        btn_OK.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent event) {
                String L_pathBD, L_pass, L_passEnc;
                Utils.G_patBD = "";
                Utils.pass = "";
                Utils.passEncripted = "";
                Utils.isBDOpenEnc = false;
                Utils.isBDOpenEncMismaPass = false;

                L_pathBD = inputbrowse.getText().trim();          //pathBD
                L_pass = String.valueOf(inputpass.getPassword()); //pass
                L_passEnc =  String.valueOf(text_passEnc.getPassword()); //pass de encriptación

                //comprobando los campos
                 if ( !L_pathBD.equals("")  && !L_pass.equals("")){

                     if (flagG == true ) { //Abrir BD

                         //Actualizando el título de la ventana
                         File file = new File(L_pathBD);
                         GUIMain.windows.setTitle("Archivador V1.0.1 - " + file.getName());

                         if (checkBox_isEcrBD.isSelected()){ //Si la BD esta encriptada

                             if (checkBox_mismopass.isSelected() == true){


                                 Utils.isBDOpenEnc = true; //flag que dice que la BD se tuvo que desencriptar para abrirse
                                 Utils.isBDOpenEncMismaPass = true;//flag que dice que la BD se desencriptó con el mismo pass
                                 Utils.G_patBD = L_pathBD;
                                 Utils.pass = L_pass;
                                 Utils.passEncripted = "";
                                 Utils.decryptFile(L_pass,L_pathBD,L_pathBD);//desencriptando BD...

                             }else{ //Si NO esta encriptada con el mismo pass
                                 //Chequeando que se haya puesto el pass de encriptación:

                                 if (!L_passEnc.equals("")){
                                     Utils.isBDOpenEnc = true; //flag que dice que la BD se tuvo que desencriptar para abrirse
                                     Utils.isBDOpenEncMismaPass = false;//flag que dice que la BD se desencriptó con el mismo pass
                                     Utils.G_patBD = L_pathBD;
                                     Utils.pass = L_pass;
                                     Utils.passEncripted = L_passEnc; //almacenando la contraseña de encriptado

                                     Utils.decryptFile(L_passEnc,L_pathBD,L_pathBD);//desencriptando...

                                 }else{
                                     JOptionPane.showMessageDialog(dialog,"Debe colocar una contraseña de encriptación");
                                 }

                             }

                         }else{ //La BD no esta encriptada
                             Utils.G_patBD = L_pathBD;
                             Utils.pass = L_pass;
                             Utils.passEncripted ="";
                         }

                     }else{ //Crear BD

                         if (checkBox_isEcrBD.isSelected() ){ //Si la BD se va a encriptar

                             if (checkBox_mismopass.isSelected() == true){

                                 //intentando crear la BD
                                 try {
                                     Utils.crearBDY(L_pathBD, L_pass);
                                 } catch (Exception f) {
                                     JOptionPane.showMessageDialog(dialog,"Error 1: " + f);
                                 }
                                 //Encriptando la BD
                                if (Utils.encryptFile(L_pass,L_pathBD,L_pathBD) == false){
                                    JOptionPane.showMessageDialog(dialog,"Error al encriptar la BD");
                                }

                             }else {// Si no es con el mismo pass: encriptando con una clave dada
                                    //Comprobando si se ha dado una clave de encriptacion

                                 if(!L_passEnc.equals("")){
                                     //intentando crear la BD
                                     try {
                                         Utils.crearBDY(L_pathBD, L_pass);
                                     } catch (Exception f) {
                                         JOptionPane.showMessageDialog(dialog,"Error 2: "+ f);
                                     }
                                     //Encriptando la BD
                                    if (!Utils.encryptFile(L_passEnc, L_pathBD, L_pathBD)){
                                        JOptionPane.showMessageDialog(dialog,"Error al encriptar la BD");
                                    }
                                 }else{//si no se ha dado una clave de encriptación
                                     JOptionPane.showMessageDialog(dialog,"Debe colocarse una clave de encriptación");
                                 }

                             }


                         }else{//si no hay que encriptar la BD";

                             try {
                                 Utils.crearBDY(L_pathBD, L_pass);
                             } catch (Exception e) {
                                 JOptionPane.showMessageDialog(dialog,"Error al crear la BD: " + e);
                             }

                         }
                     }

                     dialog.dispose();
                 }else{
                     JOptionPane.showMessageDialog(dialog,"Debe colocar una contraseña y dirección válida");
                 }
            }
        });

        //Boton Cancel
        btn_Cancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dialog.dispose();
            }
        });

    }

}